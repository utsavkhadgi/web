<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p id="demo"></p>

	<script type="text/javascript">
			var xhttp = new XMLHttpRequest();

			xhttp.onreadystatechange = function(){
				if (this.readyState == 4 && this.status == 200){

					var res=JSON.parse(xhttp.responseText);
					document.getElementById('demo').innerHTML = res.people[2].name;

				}

			};

			xhttp.open("GET","data.json",true);
			xhttp.send();

	</script>

</body>
</html>