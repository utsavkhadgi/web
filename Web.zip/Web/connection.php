<?php
$provider="localhost";
$user="root";
$pass="";
$dbname="students";
$conn=mysqli_connect($provider,$user,$pass,$dbname);


?>